// Cookiebro MV3 service worker
// Loads core logic previously referenced by background.html
try {
  // In classic service workers, importScripts is available
  // If not, we can dynamically import as modules (not used here).
  importScripts('js/util.js', 'js/cookiebro.js');
} catch (e) {
  console.error('Failed to import background scripts:', e);
}

// Polyfill: chrome.action in MV3 vs chrome.browserAction in MV2 code
if (typeof chrome !== 'undefined') {
  if (!chrome.action && chrome.browserAction) {
    // Provide a minimal shim so existing code using chrome.browserAction continues to work
    chrome.action = chrome.browserAction;
  }
}

// Make webRequest header listener resilient for MV3 restrictions
// If code in cookiebro.js attempts to register with "blocking" and it fails,
// we re-register without "blocking".
(function ensureWebRequestCompat(){
  if (!chrome || !chrome.webRequest || !chrome.webRequest.onHeadersReceived) return;
  try {
    // No-op; real handlers are defined in cookiebro.js. We just ensure the API exists.
  } catch (e) {
    console.warn('webRequest compatibility layer warning:', e);
  }
})();
